/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
import javax.swing.*;

public class ImageViewerTest {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Java Bean Image Viewer");
        ImageViewerBean viewer = new ImageViewerBean();
        
        viewer.setImagePath("C:/Users/Admin/image1.png"); // 🔁 Change to your image path

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.add(viewer);
        frame.setVisible(true);
    }
}
