/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employee;

public class Employee {
    private int empNo;
    private double basicPay;

    // Constructor to initialize employee number
    public Employee(int empNo) {
        this.empNo = empNo;
    }

    // Overloaded method to set basic pay (double)
    public void setBasicPay(double pay) {
        this.basicPay = pay;
    }

    // Overloaded method to set basic pay (int)
    public void setBasicPay(int pay) {
        this.basicPay = (double) pay;
    }

    // Method to display employee details
    public void display() {
        System.out.println("Employee Number: " + empNo);
        System.out.println("Basic Pay: " + basicPay);
    }
}

