/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import employee.Employee;

public class MainApp {
    public static void main(String[] args) {
        // Creating employee object with employee number
        Employee emp1 = new Employee(101);

        // Setting basic pay using overloaded methods
        emp1.setBasicPay(50000);     // int
        // emp1.setBasicPay(50000.75); // double (you can test this too)

        // Display employee information
        emp1.display();
    }
}
